export const getSubdomain = (): string | null => {
    const hostname = window.location.hostname;

    // Localhost support (e.g., client.localhost or custom.localhost)
    if (hostname.includes('localhost')) {
        const parts = hostname.split('.');
        // If we have distinct parts and it's not just "localhost" (1 part)
        // and typically "sub.localhost" has 2 parts.
        // However, usually developers map defaults like "app.localhost".
        if (parts.length >= 2 && parts[0] !== 'www' && parts[0] !== 'app') {
            return parts[0];
        }
        return null;
    }

    // Production (e.g., sub.teranexus.com.br)
    const parts = hostname.split('.');
    // Assumes domain.com.br (3 parts usually for simple, but .com.br is 3 parts?)
    // teranexus.com.br = 3 parts [teranexus, com, br]
    // sub.teranexus.com.br = 4 parts [sub, teranexus, com, br]
    // Vercel app: project.vercel.app = 3 parts [project, vercel, app]

    // Let's implement a more robust check based on main domain
    const MAIN_DOMAINS = ['teranexus.com.br', 'teranexus.vercel.app', 'nexus-saas.vercel.app']; // Add production domains

    let isMainDomain = false;
    let domainPartsCount = 0;

    // Simple heuristic: if parts > 2 (domain.com) or parts > 3 (domain.com.br)
    // Logic: if first part is NOT 'www' and NOT 'app', and likely has a subdomain

    // Better approach: Check if it's strictly a subdomain of our known roots
    // But we might be strictly dynamic.

    // Let's go with generic: extract the first part if it's not 'www' or 'app'
    // and the total length implies a subdomain.

    if (parts.length >= 3) {
        const subdomain = parts[0];
        if (subdomain !== 'www' && subdomain !== 'app' && subdomain !== 'trg-nexus-saas') {
            // Exclude the Vercel project name itself if accessing directly (trg-nexus-saas.vercel.app is the main app)
            // But actually, trg-nexus-saas.vercel.app IS the main app.
            // So if parts[0] is the project ID, it's NOT a custom subdomain.
            // Hardcoding the deployment ID is tricky.

            return subdomain;
        }
    }

    return null;
};
