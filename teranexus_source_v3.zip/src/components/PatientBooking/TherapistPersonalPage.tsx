import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
    CheckCircle2,
    Calendar,
    MapPin,
    Star,
    Clock,
    ShieldCheck,
    BrainCircuit,
    ArrowRight,
    MessageCircle
} from 'lucide-react';

const TherapistPersonalPage: React.FC = () => {
    const { therapistId } = useParams();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);

    // Mock Data - In production this would fetch from Supabase based on methods used in BookingWizard
    const [therapist, setTherapist] = useState<any>(null);

    useEffect(() => {
        // Simulate API fetch
        setTimeout(() => {
            setTherapist({
                id: therapistId || '1',
                name: 'Dr. Ricardo Silva',
                title: 'Psicoterapeuta & Especialista em TRG',
                crp: '06/12345',
                bio: 'Especialista em tratamento de ansiedade e traumas emocionais. Utilizo a metodologia TRG para ajudar meus pacientes a reprocessarem dores do passado e construírem um futuro mais leve. Mais de 500 vidas transformadas.',
                rating: 4.9,
                reviews: 128,
                location: 'Online & Presencial (São Paulo, SP)',
                specialties: ['Ansiedade', 'Depressão', 'Traumas', 'Fobias'],
                imageUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
                isVerified: true
            });
            setLoading(false);
        }, 800);
    }, [therapistId]);

    if (loading) {
        return (
            <div className="min-h-screen bg-slate-50 flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
            </div>
        );
    }

    if (!therapist) return null;

    return (
        <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
            {/* Top Bar / Trust Badge */}
            <div className="bg-white border-b border-slate-200 py-3 px-4 shadow-sm fixed top-0 w-full z-20">
                <div className="max-w-3xl mx-auto flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <img src="/logo.png" alt="TeraNexus" className="h-6 opacity-80" />
                        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider hidden sm:block">Profissional Verificado</span>
                    </div>
                    {therapist.isVerified && (
                        <div className="flex items-center gap-1.5 bg-green-50 text-green-700 px-3 py-1 rounded-full text-xs font-bold border border-green-100">
                            <ShieldCheck size={14} />
                            <span>Perfil Oficial</span>
                        </div>
                    )}
                </div>
            </div>

            <main className="pt-20 pb-12 px-4">
                <div className="max-w-3xl mx-auto space-y-6">

                    {/* Hero Profile Card */}
                    <div className="bg-white rounded-3xl shadow-xl shadow-slate-200/50 overflow-hidden border border-slate-100 relative">
                        {/* Banner Background */}
                        <div className="h-32 bg-gradient-to-r from-indigo-600 to-purple-600 relative">
                            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
                        </div>

                        <div className="px-6 pb-8 relative">
                            {/* Avatar */}
                            <div className="absolute -top-16 left-6 p-1.5 bg-white rounded-2xl shadow-lg rotate-3 hover:rotate-0 transition-transform duration-500">
                                <img
                                    src={therapist.imageUrl}
                                    alt={therapist.name}
                                    className="w-32 h-32 rounded-xl object-cover"
                                />
                                <div className="absolute bottom-4 right-4 bg-green-500 w-4 h-4 rounded-full border-4 border-white shadow-sm" title="Online Agora"></div>
                            </div>

                            {/* Header Info */}
                            <div className="ml-0 sm:ml-40 mt-4 sm:mt-2 pt-16 sm:pt-2 flex flex-col sm:flex-row justify-between items-start gap-4">
                                <div>
                                    <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 flex items-center gap-2">
                                        {therapist.name}
                                        <CheckCircle2 size={24} className="text-blue-500 fill-blue-50" />
                                    </h1>
                                    <p className="text-indigo-600 font-medium">{therapist.title}</p>
                                    <p className="text-sm text-slate-500 mt-1">CRP: {therapist.crp}</p>
                                </div>
                                <div className="flex flex-col items-end gap-1">
                                    <div className="flex items-center gap-1 bg-amber-50 text-amber-900 px-3 py-1 rounded-lg border border-amber-100 font-bold text-sm">
                                        <Star size={14} className="fill-amber-500 text-amber-500" />
                                        {therapist.rating} <span className="text-amber-700/60 font-normal">({therapist.reviews} avaliações)</span>
                                    </div>
                                    <span className="text-xs text-slate-400 flex items-center gap-1">
                                        <MapPin size={12} /> {therapist.location}
                                    </span>
                                </div>
                            </div>

                            {/* Bio */}
                            <div className="mt-8">
                                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide mb-3 flex items-center gap-2">
                                    <BrainCircuit size={16} className="text-indigo-500" /> Sobre mim
                                </h3>
                                <p className="text-slate-600 leading-relaxed text-lg">
                                    {therapist.bio}
                                </p>
                            </div>

                            {/* Specialties Pills */}
                            <div className="mt-6 flex flex-wrap gap-2">
                                {therapist.specialties.map((spec: string) => (
                                    <span key={spec} className="px-3 py-1 bg-slate-100 text-slate-600 rounded-lg text-sm font-medium hover:bg-slate-200 transition-colors cursor-default">
                                        {spec}
                                    </span>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* How it Works / Benefits */}
                    <div className="grid md:grid-cols-2 gap-4">
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                            <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center mb-4">
                                <Clock size={20} />
                            </div>
                            <h3 className="font-bold text-slate-900">Sessão de 50 minutos</h3>
                            <p className="text-sm text-slate-500 mt-2">Duração ideal para aprofundarmos nas questões emocionais com calma e foco.</p>
                        </div>
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                            <div className="w-10 h-10 bg-green-50 text-green-600 rounded-xl flex items-center justify-center mb-4">
                                <MessageCircle size={20} />
                            </div>
                            <h3 className="font-bold text-slate-900">Suporte Humanizado</h3>
                            <p className="text-sm text-slate-500 mt-2">Acompanhamento próximo. Você não estará sozinho(a) em sua jornada.</p>
                        </div>
                    </div>

                    {/* CTA Floating Bar (Mobile) & Static (Desktop) */}
                    <div className="sticky bottom-6 z-30">
                        <button
                            onClick={() => navigate(`/agendar/u/${therapist.id}`)}
                            className="w-full bg-slate-900 hover:bg-black text-white p-4 rounded-2xl shadow-2xl flex items-center justify-between group transition-all transform hover:scale-[1.01]"
                        >
                            <div className="text-left">
                                <p className="text-xs text-slate-400 font-medium uppercase tracking-wider mb-0.5">Próximo passo</p>
                                <p className="font-bold text-lg">Visualizar Horários Disponíveis</p>
                            </div>
                            <div className="bg-white/10 p-3 rounded-xl group-hover:bg-white/20 transition-colors">
                                <ArrowRight size={24} className="text-white" />
                            </div>
                        </button>
                        <p className="text-center text-xs text-slate-400 mt-3 flex items-center justify-center gap-1">
                            <ShieldCheck size={12} /> Pagamento seguro & dados criptografados via TeraNexus
                        </p>
                    </div>

                </div>
            </main>
        </div>
    );
};

export default TherapistPersonalPage;
